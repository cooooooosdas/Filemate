### Task 1: 补齐有界展示读合同和刷新回执定位

**Files:** 修改后端 `models.py`、`api.py`、`snapshot.py`、`repository.py`、`commands.py`，新增 `context.py`、`test_context.py`；扩展 `test_snapshot.py`、`test_commands.py`、`test_api.py`、`API_SPEC.md`。

**Interfaces:** 消费 `ScopeRequest`、`OperationReceipt`、`OrchestratorRepository.today()` 和同空间Artifact；产出共享接口中的 `read_goal_options`、目标标签、`latest_operation` 与 `ui_contract`。

- [ ] 1. 先写 `test_goal_options_are_paged_and_private`：65个原创目标分三页；第二页offset30、items30、total65；q中的 `%`、`_` 按普通字符；返回无tasks/gaps/原回答，外空间记录0条。损坏JSON仍有可识别的disabled条目，不能阻塞整页；非法offset和额外字段422。
- [ ] 2. 写 `test_day_receipt_pointer_is_atomic_and_backward_readable`：确认后关闭重开仓储，`today.latest_operation.operation_id == receipt.operation_id`；撤销后为撤销回执；注入事务失败时日安排和回执均不部分保存；旧B日Artifact无指针仍可读；指针类型／日期／修订不匹配返回null，不引用其他记录。快照标签没有旧全局画像，重命名使旧证据版本失效。
- [ ] 3. 运行 `uv run pytest filemate/tests/orchestrator/test_context.py filemate/tests/orchestrator/test_snapshot.py filemate/tests/orchestrator/test_commands.py filemate/tests/orchestrator/test_api.py -q`，先看到新增断言失败；实现上述接口。目录用参数化SQL、普通列搜索和固定30行分页，分页后再解码内容，不依赖新JSON语法；仅读取 `reverse_goal_plan`。新日指针为兼容元数据，不新增表或migration。
- [ ] 4. 重跑同一命令，预期全通过；读操作前后业务表指纹相同，默认关闭仍拒绝新读入口，历史回执可读。同步API示例，说明老日安排没有定位指针时仍可凭原request_key查询。
- [ ] 5. 仅暂存本任务文件，提交 `feat(orchestrator): 补齐工作台展示与回执定位合同`。

